const petals = document.getElementById('petals');
const petalSymbols = ['✧', '♡', '❀', '·'];
function makePetal() {
  const p = document.createElement('span');
  p.className = 'petal';
  p.textContent = petalSymbols[Math.floor(Math.random() * petalSymbols.length)];
  p.style.left = Math.random() * 100 + 'vw';
  p.style.fontSize = (10 + Math.random() * 16) + 'px';
  p.style.setProperty('--drift', (Math.random() * 180 - 90) + 'px');
  p.style.animationDuration = (8 + Math.random() * 9) + 's';
  petals.appendChild(p);
  setTimeout(() => p.remove(), 18000);
}
for (let i = 0; i < 18; i++) setTimeout(makePetal, i * 250);
setInterval(makePetal, 650);

const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLinks');
menuToggle.addEventListener('click', () => navLinks.classList.toggle('open'));
navLinks.querySelectorAll('a').forEach(link => link.addEventListener('click', () => navLinks.classList.remove('open')));

document.getElementById('sealBtn').addEventListener('click', () => {
  const wish = document.getElementById('wishReveal');
  wish.classList.toggle('show');
  document.getElementById('sealBtn').textContent = wish.classList.contains('show') ? 'Keep this little wish close ✧' : 'Open one last little wish ✧';
});

// A tiny original melody using the browser's audio synthesizer (no song file needed).
let audioContext = null, melodyTimer = null, noteIndex = 0;
const notes = [523.25, 659.25, 783.99, 659.25, 587.33, 659.25, 523.25, 392.00];
function playNote() {
  if (!audioContext) return;
  const now = audioContext.currentTime;
  const osc = audioContext.createOscillator();
  const gain = audioContext.createGain();
  osc.type = 'sine';
  osc.frequency.value = notes[noteIndex % notes.length];
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(0.07, now + 0.05);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.55);
  osc.connect(gain); gain.connect(audioContext.destination);
  osc.start(now); osc.stop(now + 0.58);
  noteIndex++;
}
const songBtn = document.getElementById('songBtn');
songBtn.addEventListener('click', async () => {
  if (melodyTimer) {
    clearInterval(melodyTimer); melodyTimer = null;
    document.getElementById('songText').textContent = 'Play a little melody';
    document.getElementById('songIcon').textContent = '♫';
    return;
  }
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  if (!AudioCtx) { alert('Audio is not supported in this browser.'); return; }
  audioContext = audioContext || new AudioCtx();
  if (audioContext.state === 'suspended') await audioContext.resume();
  playNote(); melodyTimer = setInterval(playNote, 620);
  document.getElementById('songText').textContent = 'Pause the melody';
  document.getElementById('songIcon').textContent = 'Ⅱ';
});
