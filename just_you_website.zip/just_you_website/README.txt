JUST YOU... A LITTLE STORY

HOW TO OPEN
1. Extract the ZIP folder.
2. Open the just_you_website folder.
3. Double-click index.html (or open it with Live Server in VS Code).

FILES
- index.html: website content
- style.css: design and animations
- script.js: falling petals, mobile menu, wish reveal, and original generated melody
- images/couple.png: generated romantic illustration used in the page

TO PERSONALIZE
Open index.html in VS Code and edit the letter inside the section with id="letter".
This website uses an original little synthesized melody, not a commercial song.
For GitHub Pages, upload index.html, style.css, script.js, and the images folder to your repository.
